from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-nl7c9vth4ew$^_hd*hifqtn^uahqjctjmn+t6xo#a+!w)lvo6o'

DEBUG = True

ALLOWED_HOSTS = []

INSTALLED_APPS = [
    'jazzmin',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'farmer',
    'supplier',
    'core',
    'authentication',
    'dealer',
    'crispy_forms',
    "crispy_bootstrap5",
    'tinymce',
    'mathfilters'
]

CRISPY_ALLOWED_TEMPLATE_PACKS = "bootstrap5"

CRISPY_TEMPLATE_PACK = "bootstrap5"

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'bananaMain.urls'

#TEMPLATE_DIRS = [os.path.join(BASE_DIR, 'templates')]

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]


WSGI_APPLICATION = 'bananaMain.wsgi.application'

# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.sqlite3',
#         'NAME': BASE_DIR / 'db.sqlite3',
#     }
# }

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'banana_production',
        'USER': 'root',
        'PASSWORD': '20000',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

STATICFILES_DIRS = [
    os.path.join(BASE_DIR, 'static'),
]

STATIC_URL = '/static/'
# STATIC_ROOT = 'static'

LOGIN_URL = '/login/' 
LOGOUT_REDIRECT_URL = 'home'

AUTH_USER_MODEL = 'authentication.CustomUser'


DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'



JAZZMIN_SETTINGS = {
    "site_title": "Administrator",
    "login_logo": "/static/images/bananadefault.jpg",
    "welcome_sign": "Admin",
    "site_logo": "images/bananadefault.jpg",
    "site_header": "Admin",

    "site_logo_classes": None,
    "site_icon": None,
    "site_avatar": '',
    # "language_chooser":True,
    "custom_css": "css/jazzmincss.css",
    "hide_apps": [
        'auth'
    ],
    "hide_models": [
    ],
    "topmenu_links": [

        # Url that gets reversed (Permissions can be added)

        # model admin to link to (Permissions checked against model)

        # App with dropdown menu to all its models pages (Permissions checked against models)
        # {"app": "core"},
    ],


    "order_with_respect_to": ["farmer", "supplier", "authentication", "core"],
    "icons": {

        "authentication.CustomUser": "fas fa-users-cog",
        "usermenu_links.Support": "fas fa-users-cog",
        "auth.Group": "fas fa-users",
        "farmer":"fa fa-user",
        "supplier":"fa fa-truck",
        "authentication": "fa fa-users",

    },
}


JAZZMIN_UI_TWEAKS = {
    "theme": "litera",
    # "dark_mode_theme": "darkly",
    "sidebar": "bg-light",
    # "sidebar_nav_legacy_style": True,
    "navbar": "navbar-navy",
    # "footer": "bg-danger",
    "navbar_fixed": True,
    "sidebar_fixed": True,
    # "sidebar": "bg-dark",
}


# Send emails

EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
EMAIL_HOST = "smtp.gmail.com"
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = "munezerowilly5@gmail.com"
EMAIL_HOST_PASSWORD = "mtufaapvxeqoxnvy"

PASSWORD_RESET_TIMEOUT  = 14400