
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from django.conf.urls.static import static
from django.conf import settings
from farmer.models import *
from authentication.models import CustomUser

urlpatterns = [
    path('admin/', admin.site.urls, {'extra_context': {
        'users': CustomUser.objects.all(),
        'farmers': CustomUser.objects.filter(user_type='farmer'),
        'suppliers': CustomUser.objects.filter(user_type='supplier'),
        # 'faculties': Faculties.objects.all(),
    }}),
    path('', include('authentication.urls')),
    path('', include('core.urls')),
    path('farmer/', include('farmer.urls')),
    path('supplier/', include('supplier.urls')),
    path('dealer/', include('dealer.urls')),
    path("logout/", auth_views.LogoutView.as_view(next_page='home'), name="logout"),
    path('tinymce/', include('tinymce.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
