from django.shortcuts import render, redirect
from .models import *
from core.forms import UserForm
from .forms import *
from core.decorators import supplier_redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from itertools import groupby

@supplier_redirect
@login_required
def dashboard(request):
    orders = FertilizerRequest.objects.filter(supplier=request.user)
    total_orders_amount = sum( x.quantity*x.category.price for x in FertilizerRequest.objects.filter(supplier=request.user))
    stock = FertilizerStock.objects.filter(user=request.user)
    total_stock_amount = sum( x.quantity*x.category.price for x in FertilizerStock.objects.filter(user=request.user))

    context = {
        'orders': orders,
        'total_orders_amount': total_orders_amount,
        'total_stock_amount': total_stock_amount,
        'stock': stock
    }
    return render(request, 'supplier/dashboard.html', context)

@supplier_redirect
@login_required
def orders(request):
    orders = FertilizerRequest.objects.filter(supplier=request.user).order_by('-created')
    if request.method == 'POST':
        order = FertilizerRequest.objects.get(id=request.POST['orderid'])
        if 'approve-btn' in request.POST:
            order.status = 'accepted'
            order.save()
            messages.success(request, 'Order Approved')
        if 'disapprove-btn' in request.POST:
            order.status = 'disapproved'
            order.description = request.POST['description']
            order.save()
            messages.success(request, 'Order Dissaproved')
        if 'complete-btn' in request.POST:
            order.status = 'completed'
            order.save()
            messages.success(request, 'Order Completed! You should hurry to deliver the fertilizer to the client!')
        
        return redirect(request.path_info)
    context = {
        'orders': orders
    }
    return render(request, 'supplier/orders.html', context)

@supplier_redirect
@login_required
def stock(request):
    fertilizerstock = FertilizerStock.objects.filter(user=request.user)
    stockform = StockForm()
    if request.method == 'POST':
        if 'add-stock-btn' in request.POST:
            FertilizerStock.objects.create(
                user = request.user,
                category = FertilizerCategory.objects.get(id=request.POST['category']),
                quantity = request.POST['quantity']
            )
        return redirect(request.path_info)

    context = {
        'fertilizerstock': fertilizerstock,
        'stockform': stockform
    }
    return render(request, 'supplier/stock.html', context)

@login_required
def profile(request):
    userform = UserForm(instance=request.user)
    if request.method == 'POST':
        if 'profile-picture-btn' in request.POST:
            request.user.profile_picture = request.FILES['profile_picture']
            request.user.save()
            messages.success(request, 'Picture updated successfully')
        if 'profile-update-btn' in request.POST:
            request.user.first_name = request.POST['first_name']
            request.user.last_name = request.POST['last_name']
            request.user.email = request.POST['email']
            request.user.province = request.POST['province']
            request.user.district = request.POST['district']
            request.user.sector = request.POST['sector']
            request.user.village = request.POST['village']
            request.user.national_id = request.POST['national_id']
            request.user.phone = request.POST['phone']
            request.user.save()
            messages.success(request, 'Profile Updated Successfully')
        return redirect(request.path_info)
    context = {
        'userform': userform
    }
    return render(request, 'core/profile.html', context)


def report_filter(request):
    if request.method == 'POST':
        status = request.POST['category']
        return redirect('supplier-report', status)
    return render(request, 'core/report_filter.html')


@supplier_redirect
@login_required
def report(request, status):
    if status == 'None':
        total_orders = FertilizerRequest.objects.filter(supplier=request.user, status=None)
    else:
        total_orders = FertilizerRequest.objects.filter(supplier=request.user, status=status)
    total_amount = sum(item.category.price * item.quantity for item in total_orders)

    # Stats
    # fertilizer_requests_by_category = FertilizerRequest.objects.filter(user__sector=request.user.sector).order_by('category')
    fertilizer_requests = FertilizerRequest.objects.filter(user__sector=request.user.sector).order_by('-created')
    grouped_data = {}
    for key, group in groupby(total_orders, key=lambda x: x.category):
        grouped_data[key] = list(group)
    total_by_categories = {}
    for category, items in grouped_data.items():
        total_by_categories[category] = sum(item.category.price * item.quantity for item in items)
    # End Stats

    context = {
        'total_orders': total_orders,
        'total_amount': total_amount,
        'total_by_categories': total_by_categories,
        'status': status
    }
    return render(request, 'supplier/report.html', context)