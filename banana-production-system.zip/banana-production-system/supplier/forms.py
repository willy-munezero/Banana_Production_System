from django import forms
from .models import FertilizerStock

class StockForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].widget.attrs['class'] = 'form-control'
    class Meta:
        model = FertilizerStock
        exclude = ('user', )