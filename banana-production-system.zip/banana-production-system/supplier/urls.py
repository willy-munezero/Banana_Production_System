from django.urls import path
from . import views

urlpatterns = [
    path('index', views.dashboard, name='supplier'),
    path('orders', views.orders, name='orders'),
    path('stock', views.stock, name='stock'),
    path('profile', views.profile, name='supplier-profile'),
    path('report/<str:status>/', views.report, name='supplier-report'),
    path('reportfilter', views.report_filter, name='supplier-report-filter'),

]