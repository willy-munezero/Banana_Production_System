from django.db import models
from farmer.models import *
from authentication.models import CustomUser

class FertilizerStock(models.Model):
    user= models.ForeignKey(CustomUser, related_name='stock_owner', on_delete=models.CASCADE)
    category= models.ForeignKey(FertilizerCategory, related_name='category', on_delete=models.CASCADE)
    quantity= models.PositiveIntegerField(blank=False)
    created= models.DateTimeField(auto_now_add=True)
    updated= models.DateTimeField(auto_now=True)
    
    def __str__(self) -> str:
        return f"{self.user} - {self.category}"
    
    
# Approved Request Model

class AprrovedRequest(models.Model):
    request= models.ForeignKey(FertilizerRequest, related_name='Request', on_delete=models.CASCADE)
    approved_by= models.ForeignKey(CustomUser, related_name='Aproved_by', on_delete=models.CASCADE)
    amount_paid = models.PositiveBigIntegerField(null=True)
    created= models.DateTimeField( auto_now_add=True)
    updated= models.DateTimeField( auto_now=True)

    class Meta:
        verbose_name = 'Approved Request'
    
    def __str__(self) -> str:
        return self.request
    

    

