from django.contrib import admin
from supplier.models import *

# Register your models here.


    
admin.site.register(FertilizerStock)

# admin.site.register(AprrovedRequest)