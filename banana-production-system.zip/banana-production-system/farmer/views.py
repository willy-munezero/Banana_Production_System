from django.shortcuts import render, redirect
from .models import *
from itertools import groupby
from .forms import *
from core.models import *
from authentication.models import UserActivity
from core.decorators import farmer_redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from core.forms import UserForm

def notifications_function(request):
    notifications = Notification.objects.filter(
        recipient=request.user, is_read=False
    ).order_by('-timestamp')

    # for item in notifications:
    #     if item.recipient == request.user:
    #         item.is_read = True
    #         item.save()
    return notifications
@farmer_redirect
@login_required
def farmer_dashboard(request):
    if request.user.user_type == 'supplier':
        return redirect('supplier')
    elif request.user.user_type == 'dealer':
        return redirect('dealer')
    # elif request.user.user_type == 'farmer' or request.user.user_type == 'cooperative':
    #     return redirect('farmer')
    elif request.user.is_superuser:
        return redirect('admin:index')
    total_stock = sum( x.quantity for x in BananaHarvest.objects.filter(user=request.user))
    total_stock_amount = sum( x.quantity*x.category.price for x in BananaHarvest.objects.filter(user=request.user))
    fertilizer_requests = FertilizerRequest.objects.filter(user=request.user).order_by('-created')
    total_request_amount = sum( x.quantity*x.category.price for x in FertilizerRequest.objects.filter(user=request.user))

    # Land Size
    # landsize = 0 if Land.DoesNotExist() else Land.objects.get(user=request.user).size

    try:
        landsize = Land.objects.get(user=request.user).size
    except:
        landsize = 0
    if request.method == 'POST':
        land_obj, created = Land.objects.get_or_create(
            user=request.user
        )

        land_obj.size = request.POST['size']
        land_obj.save()
        messages.success(request, 'Land Size Updated!')
        landsize = land_obj.size

        return redirect(request.path_info)
            

    context = {
        'total_stock': total_stock,
        'fertilizer_requests': fertilizer_requests,
        'total_stock_amount': total_stock_amount,
        'total_request_amount': total_request_amount,
        'notifications': notifications_function(request),
        'landsize': landsize

    }
    return render(request, 'farmer/dashboard.html', context)
@farmer_redirect
@login_required
def fertilizer_requests(request):
    fertilizer_requests = FertilizerRequest.objects.filter(user=request.user).order_by('-created')
    total_fertilizer_quantity = sum([item.quantity for item in fertilizer_requests])


    print(total_fertilizer_quantity)
    activities = UserActivity.objects.filter(user=request.user)
    mylandsize = Land.objects.get(user=request.user).size
    # Stats
    fertilizer_requests_by_category = FertilizerRequest.objects.filter(user=request.user).order_by('category')
    grouped_data = {}
    for key, group in groupby(fertilizer_requests_by_category, key=lambda x: x.category):
        grouped_data[key] = list(group)
    percentages = {}
    for category, items in grouped_data.items():
        percentages[category] = round(len(items) / len(fertilizer_requests) * 100, 1)
    # End Stats

    requestform = FertilizerRequestForm()
    receiptform = FertilizerReceiptForm()
    if request.method == 'POST':
        if 'ferti-request-btn' in request.POST:
            requestform = FertilizerRequestForm(request.POST)
            if requestform.is_valid:
                FertilizerRequest.objects.create(
                        user = request.user,
                        category = FertilizerCategory.objects.get(id=request.POST.get('category')),
                        quantity = request.POST.get('quantity')
                    )
                if request.POST["fields_number"] != '':
                    for i in range(int(request.POST["fields_number"])):
                        FertilizerRequest.objects.create(
                            user = request.user,
                            category = FertilizerCategory.objects.get(id=request.POST.get('category'+str(i))),
                            quantity = request.POST.get('quantity'+str(i))
                        )
                # Recent Activity creation
                activity_type = "Fertilizer Request"
                data = "You sent a new fertilizer request."
                UserActivity.objects.create(user=request.user, activity_type=activity_type, data=data)
                # End recent activity
                messages.success(request, 'Fertilizer Request Sent Successfully')
        if 'cancel-ferti-request' in request.POST:
            request_object = FertilizerRequest.objects.get(id=request.POST.get('requestid'))
            request_object.status = 'disapproved'
            request_object.description = 'YOU CANCELLED THE REQUEST.'
            request_object.save()
            # Recent Activity creation
            activity_type = "Fertilizer Request"
            data = "You cancelled a fertilizer request."
            UserActivity.objects.create(user=request.user, activity_type=activity_type, data=data)
            # End recent activity
            messages.info(request, 'A fertilizer request denied')
        
        if 'receipt-btn' in request.POST:
            request_object = FertilizerRequest.objects.get(id=int(request.POST['requestid']))
            if request_object.receipt:
                request_object.receipt.delete(save=True)
            request_object.receipt = request.FILES['receipt']
            request_object.save()
            messages.info(request, 'Receipt Uploaded')
        return redirect(request.path_info)
    
    context = {
        'fertilizer_requests': fertilizer_requests,
        'percentages': percentages,
        'requestform': requestform,
        'receiptform': receiptform,
        'activities': activities,
        'notifications': notifications_function(request),
        'mylandsize': mylandsize,
        'total_fertilizer_quantity': total_fertilizer_quantity
    }
    return render(request, 'farmer/requests.html', context)

@farmer_redirect
@login_required
def stock(request):
    context = {}
    stock = BananaHarvest.objects.filter(user=request.user).order_by('-created')
    activities = UserActivity.objects.filter(user=request.user)
    
    grouped_data = {}
    for key, group in groupby(stock, key=lambda x: x.category):
        grouped_data[key] = list(group)
    percentages = {}
    for category, items in grouped_data.items():
        percentages[category] = round(len(items) / len(stock) * 100, 1)

    stockform = StockForm()

    if request.method == 'POST':
        if 'add-stock-btn' in request.POST:
            stockform = StockForm(request.POST)
            if stockform.is_valid:
                # try:
                #     stock_object = BananaHarvest.objects.get(user=request.user, category=BananaCategory.objects.get(id=request.POST.get('category')))
                # except:
                #     stock_object = None

                # if stock_object is None:
                BananaHarvest.objects.create(
                    user = request.user,
                    category = BananaCategory.objects.get(id=request.POST.get('category')),
                    quantity = request.POST.get('quantity')
                )

                # Recent Activity creation
                activity_type = "Stock"
                data = "You added an item to the stock."
                UserActivity.objects.create(user=request.user, activity_type=activity_type, data=data)
                # End recent activity
                messages.success(request, 'Stock added successfully')

                # else:
                #     stock_object.quantity = stock_object.quantity + int(request.POST.get('quantity'))
                #     stock_object.save()
                #     # Recent Activity creation
                #     activity_type = "Stock"
                #     data = "You updated an item quantity"
                #     UserActivity.objects.create(user=request.user, activity_type=activity_type, data=data)
                #     # End recent activity
                #     messages.success(request, 'Item quantity updated')

        if 'stock-delete-btn' in request.POST:
            stock_item = BananaHarvest.objects.get(id=request.POST['stockid'])
            stock_item.delete()
            # Recent Activity creation
            activity_type = "Stock"
            data = "You deleted a stock object."
            UserActivity.objects.create(user=request.user, activity_type=activity_type, data=data)
            # End recent activity
            messages.success(request, 'Delete Successful')

        return redirect(request.path_info)
    
    context = {
        'stockform': stockform,
        'activities': activities,
        'stock': stock,
        'percentages': percentages,
        'notifications': notifications_function(request)
    }
    return render(request, 'farmer/stock.html', context)

@login_required
def profile(request):
    userform = UserForm(instance=request.user)
    if request.method == 'POST':
        if 'profile-picture-btn' in request.POST:
            request.user.profile_picture = request.FILES['profile_picture']
            request.user.save()
            messages.success(request, 'Picture updated successfully')
        if 'profile-update-btn' in request.POST:
            request.user.first_name = request.POST['first_name']
            request.user.last_name = request.POST['last_name']
            request.user.email = request.POST['email']
            request.user.province = request.POST['province']
            request.user.district = request.POST['district']
            request.user.sector = request.POST['sector']
            request.user.village = request.POST['village']
            request.user.national_id = request.POST['national_id']
            request.user.phone = request.POST['phone']
            request.user.save()
            messages.success(request, 'Profile Updated Successfully')
        return redirect(request.path_info)
    context = {
        'userform': userform
    }
    return render(request, 'core/profile.html', context)

def invoice(request, id):
    request_obj = FertilizerRequest.objects.get(id=id)
    context = {
        'request_obj': request_obj
    }
    return render(request, 'farmer/invoice.html', context)