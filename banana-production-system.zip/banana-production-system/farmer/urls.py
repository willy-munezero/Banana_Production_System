from django.urls import path
from . import views

urlpatterns = [
    path('index', views.farmer_dashboard, name='farmer'),
    path('requests', views.fertilizer_requests, name='fertilizer-requests'),
    path('stock', views.stock, name='farmer-stock'),
    path('profile', views.profile, name='farmer-profile'),
    path('invoice/<int:id>', views.invoice, name='farmer-invoice'),

]