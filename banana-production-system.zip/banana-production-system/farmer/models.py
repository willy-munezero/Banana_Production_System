from django.db import models
from authentication.models import CustomUser
from django.utils import timezone
from core.models import *
from django.db.models.signals import post_save
# from django.dispatch import receiver
# Email related imports.
from django.template import Context
from django.utils.translation import gettext_lazy as _
from django.db.models.signals import pre_save
from django.dispatch import receiver
from django.core.mail import EmailMultiAlternatives
import os
from email.mime.image import MIMEImage
from django.template.loader import get_template


# Farmer Model
class Farmer(models.Model):
  
    user = models.ForeignKey(CustomUser, related_name='farmers', on_delete=models.CASCADE)
    profilePicture = models.ImageField(upload_to=None, null=True, blank=True)
    tin = models.CharField(max_length=50, blank=False)
    province = models.CharField(max_length=50)
    district = models.CharField(max_length=50)
    sector = models.CharField(max_length=50)
    created = models.DateTimeField(default=timezone.now)
    updated = models.DateTimeField( default=timezone.now)
    
    def __str__(self):
        return self.user.username
    

    
# Fertilize Request Model

class FertilizerRequest(models.Model):
    Statuses = (
        ('disapproved', 'disapproved'),
        ('accepted', 'accepted'),
        ('completed', 'completed'),
    )
    user = models.ForeignKey(CustomUser, related_name='requester', on_delete=models.CASCADE)
    category= models.ForeignKey(FertilizerCategory, related_name='Category', on_delete=models.CASCADE)
    # quantity= models.PositiveIntegerField()
    quantity= models.PositiveIntegerField(verbose_name='Quantity [kgs]')
    receipt = models.FileField(upload_to='uploads/receipts', blank=True, null=True)
    status = models.CharField(max_length=20, choices=Statuses, null=True, blank=True)
    description = models.CharField(max_length=200, null=True, blank=True)
    supplier = models.ForeignKey(CustomUser, on_delete=models.CASCADE, null=True, blank=True)
    created= models.DateTimeField(auto_now_add=True)
    updated= models.DateTimeField(auto_now=True)

    def calculate_size(self):
        return FertilizerRequest.objects.count()

    def __str__(self):
        return self.user.username +' - ' + self.category.name


# Banana Harvest Model

class BananaHarvest(models.Model):
    user = models.ForeignKey(CustomUser, related_name='Harvester', on_delete=models.CASCADE, verbose_name='Farmer')
    category= models.ForeignKey(BananaCategory, related_name='Category', on_delete=models.CASCADE)
    quantity= models.PositiveIntegerField(blank=False, verbose_name='Quantity [Kgs]')
    created= models.DateTimeField( auto_now_add=True)
    updated= models.DateTimeField( auto_now=True)
    
    def __str__(self):
        return self.user.username

class Land(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, verbose_name='Farmer')
    size = models.IntegerField(null=True, blank=True)
    
    def __str__(self):
        return self.user.first_name



current_directory = os.getcwd()
image_file = open(current_directory + '/static/images/bananadefault.jpg', 'rb')
msg_image = MIMEImage(image_file.read())
image_file.close()
msg_image.add_header('Content-ID', '<image1>')
htmly = get_template('emails/messages.html')


@receiver(pre_save, sender=FertilizerRequest)
def requestAcceptedEmails(sender, instance, **kwargs):
    if instance.status and sender.objects.get(pk=instance.id).status != instance.status and instance.status == 'completed':
        mail_subject = "Request Completed"
        data = Context({
            'user': instance.user.username,
            'text': 'Your fertilizer request has been Completed, download your invoice and go pick your fertilizer'
        }).flatten()
        html_content = htmly.render(data)
        email = EmailMultiAlternatives(mail_subject, html_content, to=[instance.user.email])
        email.attach_alternative(html_content, "text/html")
        email.attach(msg_image)
        email.send()

    if instance.status and sender.objects.get(pk=instance.id).status != instance.status and instance.status == 'disapproved':
        mail_subject = "Request Rejected"
        data = Context({
            'user': instance.user.username,
            'text': 'Your fertilizer request has been disapproved by the supplier due to the following reasons: <br><b><i>'+instance.description+'</i></b><br>We are sorry for the inconvenience.',
        }).flatten()
        html_content = htmly.render(data)
        email = EmailMultiAlternatives(mail_subject, html_content, to=[instance.user.email])
        email.attach_alternative(html_content, "text/html")
        email.attach(msg_image)
        email.send()