from django.contrib import admin
from .models import *

from import_export.admin import ExportActionMixin
from import_export import resources
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from django.http import HttpResponse
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Image
from reportlab.lib.styles import getSampleStyleSheet
from datetime import datetime
import os
from django.contrib import admin
from import_export.fields import Field
from import_export.formats import base_formats
from django.db.models.fields import BLANK_CHOICE_DASH

class FarmerDamin(admin.ModelAdmin):
    model= Farmer
    fields = ("profilePicture","Tin")
admin.site.register(Farmer,FarmerDamin)

    

# admin.site.register(BananaHarvest)

    

class FertiRequestsResource(resources.ModelResource):
    def get_export_headers(self):
        headers = super().get_export_headers()
        for i, h in enumerate(headers):
            if h == 'fname':
                headers[i] = "First Name"
            if h == 'lname':
                headers[i] = "Last Name"
        return headers
    
    class Meta:
        model = FertilizerRequest
        exclude = ('id', 'user')

class DisplayBananaHarvest(admin.ModelAdmin):
    list_display = ['user','category', 'quantity', 'created']
    
    # resource_class = FertiRequestsResource
    date_hierarchy = 'created'
    list_filter = ['category','created', 'user__sector']

    # Remove Dashes on Select Action Dropdown
    def get_action_choices(self, request):
        default_choices = [("", "Select action")]
        return super(DisplayBananaHarvest, self).get_action_choices(request, default_choices)

    def Print_Report(self, request, queryset):
        sector = request.GET.get('user__sector') if request.GET.get('user__sector') is not None else ""
        year = request.GET.get('created__year') if request.GET.get('created__year') is not None else str(datetime.now().year)
        month = request.GET.get('created__month') if request.GET.get('created__month') is not None else str(datetime.now().month)
        day_ = request.GET.get('created__day') if request.GET.get('created__day') is not None else str(datetime.now().day)
        pdf_export_title = "List of Banana Harvest in "+sector+" sector as"+" on "+ day_+", "+month+", "+year
        queryset_for_export = queryset
        return export_statistics(self, request, queryset_for_export, pdf_export_title)
    
    actions = ['Print_Report']

def export_statistics(self, request, queryset=None, title=None):
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="ReportExport.pdf"'
    doc = SimpleDocTemplate(response, pagesize=letter)
    p = canvas.Canvas(response, pagesize=letter)
    elements = []

    logo_path = os.getcwd() + '\static\images\\reportlogo.PNG'
    image = Image(logo_path, width=450, height=50) # You can add hAlign='LEFT' attribute to position image
    elements.append(image)
    header = 'RWANDA AGRICULTURAL AND ANIMAL RESOURCES'
    location = 'Rubona, Huye District'
    email = 'info@rab.gov.rw'
    pobox = 'P.O Box 5016'
    elements.append(Paragraph(header))
    elements.append(Paragraph(location))
    elements.append(Paragraph(email))
    elements.append(Paragraph(pobox))
    title_margin_top = 10
    
    # Add title to the PDF (use the provided title or a default title)
    title = title if title is not None else "My Report"
    title_style = getSampleStyleSheet()['Title']
    title_style.spaceAfter = title_margin_top  # Add custom margin-top to the title
    elements.append(Paragraph(title, title_style))



    data = [['No','First Name', 'Last Name', 'Date', 'Quantity [Kgs]',]]  # Table header
    # sectors = []
    # sector_quantity_dict = {}
    # for obj in queryset:
    #     if obj.user.sector not in sectors:
    #         sectors.append(obj.user.sector)
    #         sector_quantity_dict[obj.user.sector] = obj.quantity
    #     else:
    #         sector_quantity_dict[obj.user.sector] = sector_quantity_dict[obj.user.sector] + obj.quantity
    # counter=1
    # total = 0
    # for sector, quantity in sector_quantity_dict.items():
    #     data.append([counter, sector, quantity])
    #     total += quantity
    #     counter+=1
    counter = 1
    total = 0
    for obj in queryset:
        data.append([counter, obj.user.first_name, obj.user.last_name, obj.created.strftime('%d, %m, %y'), obj.quantity])
        total += obj.quantity
        counter+=1

    data.append([""])
    data.append(["TOTAL", total, 'Kgs'])
    
    num_columns = len(data[0])
    page_width, page_height = letter
    # Calculate the total padding for left and right (you can adjust the padding value)
    padding = 50
    total_padding = padding * 2

    # Calculate the width of each column based on the page width, number of columns, and padding
    column_width = (page_width - total_padding) / num_columns

    # Set the width of each column in the table with padding
    col_widths = [column_width] * num_columns

    table = Table(data, colWidths=col_widths)

    style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), 'lightgrey'),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        # ('GRID', (0, 0), (-1, -1), 1, 'black'),
    ])
    table.setStyle(style)
    elements.append(table)

    # Get the user data (first name, last name, username) to be printed in the footer
    user_data = (request.user.first_name.strip(), request.user.last_name.strip(), request.user.username)

    # Build the document and add the footer with the user data
    doc.build(elements, onFirstPage=lambda canvas, doc: add_footer(canvas, doc, user_data),
              onLaterPages=lambda canvas, doc: add_footer(canvas, doc, user_data))

    return response








class DisplayFertiRequests(admin.ModelAdmin):
    list_display = ['category', 'status', 'created']
    resource_class = FertiRequestsResource
    date_hierarchy = 'created'
    list_filter = ['status','created']

    # Remove Dashes on Select Action Dropdown
    def get_action_choices(self, request):
        default_choices = [("", "Select action")]
        return super(DisplayFertiRequests, self).get_action_choices(request, default_choices)
    
    def Print_Report(self, request, queryset):
        status = request.GET.get('status__exact') if request.GET.get('status__exact') is not None else ""
        year = request.GET.get('created__year') if request.GET.get('created__year') is not None else str(datetime.now().year)
        month = request.GET.get('created__month') if request.GET.get('created__month') is not None else str(datetime.now().month)
        day_ = request.GET.get('created__day') if request.GET.get('created__day') is not None else str(datetime.now().day)
        pdf_export_title = "List of "+ status+" Fertilizer Requests as"+" on "+ day_+", "+month+", "+year
        queryset_for_export = queryset
        return export_pdf(self, request, queryset_for_export, pdf_export_title, status)
    
    actions = ['Print_Report']

def export_pdf(self, request, queryset=None, title=None, status=""):
    
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="ReportExport.pdf"'
    doc = SimpleDocTemplate(response, pagesize=letter)
    p = canvas.Canvas(response, pagesize=letter)
    elements = []

    logo_path = os.getcwd() + '\static\images\\reportlogo.PNG'
    image = Image(logo_path, width=450, height=50) # You can add hAlign='LEFT' attribute to position image
    elements.append(image)
    header = 'RWANDA AGRICULTURAL AND ANIMAL RESOURCES'
    location = 'Rubona, Huye District'
    email = 'info@rab.gov.rw'
    pobox = 'P.O Box 5016'
    elements.append(Paragraph(header))
    elements.append(Paragraph(location))
    elements.append(Paragraph(email))
    elements.append(Paragraph(pobox))
    title_margin_top = 10
    
    # Add title to the PDF (use the provided title or a default title)
    title = title if title is not None else "My Report"
    title_style = getSampleStyleSheet()['Title']
    title_style.spaceAfter = title_margin_top  # Add custom margin-top to the title
    elements.append(Paragraph(title, title_style))

    # Customize the layout of the data in the PDF using the 'queryset'
    if queryset.model is FertilizerRequest:
        if status=="":
            data = [['No','Category', 'Farmer', 'Location', 'Supplier', 'Status', 'Date']]  # Table header
        else:
            data = [['No','Category', 'Farmer', 'Location', 'Supplier', 'Date']]  # Table header
        counter=1
        for obj in queryset:
            if status=="":
                data.append([counter, obj.category, obj.user, obj.user.district, 'None Assigned' if obj.supplier==None else obj.supplier, 'Pending' if obj.status==None else obj.status, obj.created.strftime('%d, %m, %y')])
                counter+=1
            else:
                data.append([counter, obj.category, obj.user, obj.user.district, 'None Assigned' if obj.supplier==None else obj.supplier, obj.created.strftime('%d, %m, %y')])
                counter+=1
    elif queryset.model is BananaHarvest:
        data = [['No','Category', 'Farmer', 'Sector', 'Date']]  # Table header
        counter=1
        for obj in queryset:
            data.append([counter, obj.category, obj.user, obj.user.sector, obj.created.strftime('%d, %m, %y')])
            counter+=1

    num_columns = len(data[0])
    page_width, page_height = letter
    # Calculate the total padding for left and right (you can adjust the padding value)
    padding = 50
    total_padding = padding * 2

    # Calculate the width of each column based on the page width, number of columns, and padding
    column_width = (page_width - total_padding) / num_columns

    # Set the width of each column in the table with padding
    col_widths = [column_width] * num_columns

    table = Table(data, colWidths=col_widths)

    style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), 'lightgrey'),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        # ('GRID', (0, 0), (-1, -1), 1, 'black'),
    ])
    table.setStyle(style)
    elements.append(table)

    # Get the user data (first name, last name, username) to be printed in the footer
    user_data = (request.user.first_name.strip(), request.user.last_name.strip(), request.user.username)

    # Build the document and add the footer with the user data
    doc.build(elements, onFirstPage=lambda canvas, doc: add_footer(canvas, doc, user_data),
              onLaterPages=lambda canvas, doc: add_footer(canvas, doc, user_data))

    return response

def add_footer(canvas, doc, user_data):
    first_name, last_name, username = user_data

    if not first_name.strip() and not last_name.strip():
        footer_text = f"Printed by {username} on "+str(datetime.now())
    else:
        footer_text = f"Printed by {first_name} {last_name} on "+str(datetime.now())

    # Reduce font size
    canvas.saveState()
    canvas.setFont("Helvetica", 8)

    # Get the width and height of the footer text
    footer_paragraph = Paragraph(footer_text, getSampleStyleSheet()['Normal'])
    # footer_width, footer_height = footer_paragraph.wrap(doc.width, doc.bottomMargin)

    # Calculate the X coordinate to align the footer at the left margin
    footer_x = doc.leftMargin + 380

    # Calculate the Y coordinate to align the footer at the bottom of the page
    footer_y = doc.bottomMargin + 170

    # Draw the footer at the left margin and bottom of the page
    canvas.drawString(footer_x, footer_y, footer_text)
    canvas.restoreState()

export_pdf.short_description = "Export to PDF"

admin.site.register(FertilizerRequest, DisplayFertiRequests)
admin.site.register(BananaHarvest, DisplayBananaHarvest)
