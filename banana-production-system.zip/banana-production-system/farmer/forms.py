from django import forms
from .models import *

class FertilizerRequestForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].widget.attrs['class'] = 'form-control'
        self.fields['category'].widget.attrs['id'] = 'cat'
        self.fields['quantity'].widget.attrs['class'] = 'quantity'
        self.fields['quantity'].widget.attrs['id'] = 'first_quantity'
        
    class Meta:
        model = FertilizerRequest
        exclude = ('user', 'supplier', 'status', 'receipt', 'description')

class FertilizerReceiptForm(forms.ModelForm):     
    class Meta:
        model = FertilizerRequest
        fields = ('receipt',)

class StockForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].widget.attrs['class'] = 'form-control'

    class Meta:
        model = BananaHarvest
        exclude = ('user',)