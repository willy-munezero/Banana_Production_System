from django import template

register = template.Library()


@register.filter
def get_first_word_from_url(value):
    url_segments = value.split('/')
    first_word = url_segments[1] if len(url_segments) > 1 else ""
    return first_word