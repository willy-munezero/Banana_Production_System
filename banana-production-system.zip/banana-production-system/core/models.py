from django.db import models
from authentication.models import CustomUser
from tinymce import models as tinymce_models


class FertilizerCategory(models.Model):
    name= models.CharField( max_length=50,null=True)
    price = models.PositiveIntegerField(null=True)
    picture = models.ImageField(upload_to='uploads/bananas/categories', null=True, blank=True)
    def __str__(self) :
        return self.name

# Banana Category

class BananaCategory(models.Model):
    name= models.CharField(max_length=50)
    price = models.PositiveIntegerField(null=True)
    
    def __str__(self):
         return self.name

class Disease(models.Model):
    name = models.CharField(max_length=50)
    description = tinymce_models.HTMLField()
    symptoms = tinymce_models.HTMLField()
    prevention = tinymce_models.HTMLField()
    picture = models.ImageField(default='/static/images/bananadefault.jpg', upload_to='uploads/bananas')
    created= models.DateTimeField(auto_now_add=True)
    updated= models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class FeedBack(models.Model):
    user = models.ForeignKey(CustomUser, related_name='Sender', on_delete=models.CASCADE)
    message= models.CharField( max_length=200)
    created= models.DateTimeField(auto_now_add=True)
    updated= models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.user.username

class Notification(models.Model):
    recipient = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

