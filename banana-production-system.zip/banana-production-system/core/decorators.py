from django.http import HttpResponse
from django.shortcuts import redirect, render, reverse

def dealer_redirect(view_func):
    def wrapper_function(request, *args, **kwargs):
        if request.user.user_type == 'supplier':
            return redirect('supplier')
        elif request.user.user_type == 'farmer' or request.user.user_type == 'cooperative':
            return redirect('farmer')
        elif request.user.is_superuser:
            return redirect('admin:index')
        else:
            return view_func(request, *args, **kwargs)
    return wrapper_function

def farmer_redirect(view_func):
    def wrapper_function(request, *args, **kwargs):
        if request.user.user_type == 'supplier':
            return redirect('supplier')
        elif request.user.user_type == 'dealer':
            return redirect('dealer')
        elif request.user.is_superuser:
            return redirect('admin:index')
        else:
            return view_func(request, *args, **kwargs)
    return wrapper_function

def supplier_redirect(view_func):
    def wrapper_function(request, *args, **kwargs):
        if request.user.user_type == 'farmer' or request.user.user_type == 'cooperative':
            return redirect('farmer')
        elif request.user.user_type == 'dealer':
            return redirect('dealer')
        elif request.user.is_superuser:
            return redirect('admin:index')
        else:
            return view_func(request, *args, **kwargs)
    return wrapper_function