from django.db.models.signals import post_save
from django.dispatch import receiver
from farmer.models import FertilizerRequest
from .models import Notification
