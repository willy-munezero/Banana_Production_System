from django.contrib import admin
from .models import FertilizerCategory, BananaCategory, Disease, FeedBack, Notification

admin.site.register(FertilizerCategory)
admin.site.register(BananaCategory)
admin.site.register(Disease)
admin.site.register(FeedBack)
admin.site.register(Notification)