from django.shortcuts import render, redirect
from .models import FeedBack, Disease, FertilizerCategory
from django.contrib.auth.decorators import login_required
from django.contrib import messages

def home(request):
    feedbacks = FeedBack.objects.all()
    diseases = Disease.objects.all()
    context = {
        'feedbacks': feedbacks,
        'diseases': diseases
        }
    return render(request, 'core/index.html', context)

@login_required
def dashboard(request):
    if request.user.is_authenticated:
        if request.user.user_type=='supplier':
            return redirect('supplier')
        elif request.user.user_type=='dealer':
            return redirect('dealer')
        elif request.user.user_type=='farmer' or request.user.user_type=='cooperative':
            return redirect('farmer')
        elif request.user.is_superuser:
            return redirect('admin:index')
    else:
        return redirect('login')
    
def disease(request, id):
    disease = Disease.objects.get(id=id)
    context = {
        'disease': disease
        }
    return render(request, 'core/disease.html', context)

@login_required
def contact(request):
    if request.method == 'POST':
        if 'message-btn' in request.POST:
            FeedBack.objects.create(
                user=request.user,
                message=request.POST.get('message')
            )
        messages.success(request, 'Murakoze igitekerezo cyakiriwe!')
        return redirect('home')
    return render(request, 'core/contact.html')

def fertilizers(request):
    fertilizers = FertilizerCategory.objects.all()
    context = {
        'fertilizers': fertilizers
    }
    return render(request, 'core/fertilizers.html', context)