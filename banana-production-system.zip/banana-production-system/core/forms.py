from django import forms
from authentication.models import CustomUser

class UserForm(forms.ModelForm):
    profile_picture = forms.ImageField(
        required=True,
        widget=forms.FileInput(attrs={'class': 'form-control'})
    )
    first_name = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={'class': 'form-control'}
        )
    )
    last_name = forms.CharField(
        widget=forms.TextInput(
            attrs={'class': 'form-control'}
        )
    )
    email = forms.CharField(
        widget=forms.EmailInput(
            attrs={'class': 'form-control'}
        )
    )
    province = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={'class': 'form-control'}
        )
    )
    district = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={'class': 'form-control'}
        )
    )
    sector = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={'class': 'form-control'}
        )
    )
    village = forms.CharField(
        required=True,
        widget=forms.TextInput(
            attrs={'class': 'form-control'}
        )
    )
    national_id = forms.IntegerField(
        widget=forms.NumberInput(
            attrs={'class': 'form-control'}
        )
    )
    phone = forms.IntegerField(
        required=True,
        widget=forms.NumberInput(
            attrs={'class': 'form-control'}
        )
    )
    class Meta:
        model = CustomUser
        fields = ('profile_picture', 'first_name', 'last_name', 'email', 'province', 'district', 'sector', 'village', 'national_id', 'phone')

