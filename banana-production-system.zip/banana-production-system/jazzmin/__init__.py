version = "2.5.0"
default_app_config = "jazzmin.apps.JazzminConfig"
