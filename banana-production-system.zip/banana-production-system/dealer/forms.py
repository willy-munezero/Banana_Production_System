from django import forms
from farmer.models import FertilizerRequest
from authentication.models import CustomUser
from django.contrib.auth.forms import UserCreationForm
from django.db.models import Q
from django.contrib.auth import get_user_model

class FarmerForm(UserCreationForm):
    FARMER_CHOICES = (
        ('farmer', 'FARMER'),
        ('cooperative', 'COOPERATIVE'),
    )
    user_type = forms.ChoiceField(
        choices = FARMER_CHOICES,
        widget=forms.Select(
            attrs={
                "class": "form-control",
                })
    )
    class Meta:
        model = CustomUser
        fields = ('username', 'password1','password2', 'user_type')


class ForwardToSupplier(forms.ModelForm):
    # supplier_choices = [(user.id, user.first_name) for user in CustomUser.objects.filter(user_type='supplier')]
    supplier = forms.ModelChoiceField(
        # choices = supplier_choices,
        queryset=CustomUser.objects.filter(user_type='supplier'),
        widget=forms.Select(
            attrs={
                "class": "form-control",
                })
    
    )
    class Meta:
        model = FertilizerRequest
        fields = ('supplier',)


class FertilizerRequestForm(forms.ModelForm):
    # Farmers choices
    values_to_compare = ['farmer', 'cooperative']
    or_conditions = Q()
    for value in values_to_compare:
        or_conditions |= Q(user_type=value)
    # farmer_choices = [(user.id, user.username) for user in CustomUser.objects.filter(or_conditions)]
    user = forms.ModelChoiceField(
        queryset = CustomUser.objects.filter(or_conditions),
        label = 'Farmer/Cooperative',
        widget=forms.Select(
            attrs={
                "class": "form-control",
                })
    
    )

    # Supplier choices
    # supplier_choices = [(user.id, user.username) for user in CustomUser.objects.filter(user_type='supplier')]
    # supplier_choices.insert(0, ('', 'None'))
    supplier = forms.ModelChoiceField(
        required = False,
        initial=None,
        queryset = CustomUser.objects.filter(user_type='supplier'),
        widget=forms.Select(
            attrs={
                "class": "form-control",
                })
    )


    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].widget.attrs['class'] = 'form-control'
        self.fields['supplier'].widget.attrs['class'] = 'form-control'
        
    class Meta:
        model = FertilizerRequest
        exclude = ('status',)