from django.shortcuts import render, redirect
from farmer.models import Farmer, FertilizerRequest, FertilizerCategory
from authentication.models import CustomUser, UserActivity
from .forms import ForwardToSupplier, FarmerForm
from django.db.models import Q
from .forms import FertilizerRequestForm
from core.models import *
from itertools import groupby
from django.contrib.auth.decorators import login_required
from core.decorators import dealer_redirect
from django.contrib import messages
from core.forms import UserForm

@dealer_redirect
@login_required
def dealer_dashboard(request):
    activities = UserActivity.objects.filter(user=request.user)

    forwarded_orders = FertilizerRequest.objects.filter(
        user__district=request.user.district, user__sector=request.user.sector,
        supplier__isnull=False
        )
    unforwarded_orders = FertilizerRequest.objects.filter(
        user__district=request.user.district, user__sector=request.user.sector,
        supplier__isnull=True
        )
    total_orders = FertilizerRequest.objects.filter(user__district=request.user.district, user__sector=request.user.sector)
    
    # To get farmers and cooperatives
    values_to_compare = ['farmer', 'cooperative']
    or_conditions = Q()
    for value in values_to_compare:
        or_conditions |= Q(user_type=value)

    farmers = CustomUser.objects.filter(
        or_conditions,
        province=str(request.user.province),
        district=str(request.user.district),
        sector=str(request.user.sector),
        )
    # End

    # Stats
    fertilizer_requests_by_category = FertilizerRequest.objects.filter(user__sector=request.user.sector).order_by('category')
    fertilizer_requests = FertilizerRequest.objects.filter(user__sector=request.user.sector).order_by('-created')
    grouped_data = {}
    for key, group in groupby(fertilizer_requests_by_category, key=lambda x: x.category):
        grouped_data[key] = list(group)
    percentages = {}
    for category, items in grouped_data.items():
        percentages[category] = round(len(items) / len(fertilizer_requests) * 100, 1)
    # End Stats

    suppliers = CustomUser.objects.filter(
        user_type='supplier'
    )

    district_grouped_orders = FertilizerRequest.objects.filter(user__district=request.user.district).order_by('-created')
    sectors = []
    sectors_counter = {}
    objects = [item.user.sector for item in district_grouped_orders]
    for item in objects:
        if item not in sectors:
            sectors.append(item)
            sectors_counter[item] = 1
        else:
            sectors_counter[item] = sectors_counter[item] + 1


    context = {
        'forwarded_orders': forwarded_orders,
        'unforwarded_orders': unforwarded_orders,
        'total_orders': total_orders,
        'farmers': farmers,
        'suppliers': suppliers,
        'activities': activities,
        'percentages': percentages,
        'sectors': sectors,
        'sectors_counter': sectors_counter
    }
    return render(request, 'dealer/dashboard.html', context)
@dealer_redirect
@login_required
def farmers(request):
    activities = UserActivity.objects.filter(user=request.user)
    values_to_compare = ['farmer', 'cooperative']
    or_conditions = Q()
    for value in values_to_compare:
        or_conditions |= Q(user_type=value)

    farmers = CustomUser.objects.filter(
        or_conditions,
        province=str(request.user.province),
        district=str(request.user.district),
        sector=str(request.user.sector),
        )
    farmerform = FarmerForm()

    if request.method == 'POST':
        if 'farmer-add-btn' in request.POST:
            farmerform = FarmerForm(request.POST)
            if farmerform.is_valid():
                user = farmerform.save(commit=False)
                user.province = request.user.province
                user.district = request.user.district
                user.sector = request.user.sector
                user.village = request.user.village
                user.save()

                # Recent Activity creation
                activity_type = "Farmer Add"
                data = "You added a farmer "+user.username
                UserActivity.objects.create(user=request.user, activity_type=activity_type, data=data)
                # End recent activity
                messages.success(request, 'Farmer Added')
                return redirect(request.path_info)
        if 'disactivate-btn' in request.POST:
            user = CustomUser.objects.get(id=request.POST['farmerid'])
            if user.is_active == True:
                user.is_active = False
                # Recent Activity creation
                activity_type = "Account Disactivation"
                data = 'You disactivated '+user.username
                UserActivity.objects.create(user=request.user, activity_type=activity_type, data=data)
                # End recent activity
                messages.success(request, 'Farmer/Cooperative account disactivated')
            else:
                user.is_active = True
                # Recent Activity creation
                activity_type = "Account Activation"
                data = 'You activated '+user.username
                UserActivity.objects.create(user=request.user, activity_type=activity_type, data=data)
                # End recent activity
                messages.success(request, 'Farmer/Cooperative account activated')
            user.save()

            

            return redirect(request.path_info)


    context = {
        'farmers': farmers,
        'farmerform': farmerform,
        'activities': activities
    }
    return render(request, 'dealer/farmers.html', context)
@dealer_redirect
@login_required
def suppliers(request):
    suppliers = CustomUser.objects.filter(user_type='supplier')
    activities = UserActivity.objects.filter(user=request.user)
    
    context = {
        'suppliers': suppliers,
        'activities': activities
    }
    return render(request, 'dealer/suppliers.html', context)
@dealer_redirect
@login_required
def requests(request):
    activities = UserActivity.objects.filter(user=request.user)
    values_to_compare = [user for user in CustomUser.objects.filter(
        province=request.user.province,
        district=request.user.district,
        sector=request.user.sector
    )]
    or_conditions = Q()
    for value in values_to_compare:
        or_conditions |= Q(user=value)

    requests = FertilizerRequest.objects.filter(or_conditions).order_by('-created')
    forwardtosupplierform = ForwardToSupplier()
    requestform = FertilizerRequestForm()

    if request.method == 'POST':
        if 'forward-btn' in request.POST:
            request_object = FertilizerRequest.objects.get(id=request.POST['requestid'])
            forwardtosupplierform = ForwardToSupplier(request.POST)
            if forwardtosupplierform.is_valid:
                request_object.supplier = CustomUser.objects.get(id=request.POST['supplier'])
                request_object.save()
                # Recent Activity creation
                activity_type = "Request Forward"
                data = "You forwarded a request for "+request_object.user.username+" to "+request_object.supplier.username
                UserActivity.objects.create(user=request.user, activity_type=activity_type, data=data)
                # End recent activity
                messages.success(request, 'Request Forwarded')
        if 'new-request-btn' in request.POST:
            requestform = FertilizerRequestForm(request.POST)
            if requestform.is_valid:
                FertilizerRequest.objects.create(
                    user=CustomUser.objects.get(id=request.POST['user']),
                    category = FertilizerCategory(id=request.POST['category']),
                    quantity = request.POST['quantity'],
                    supplier = CustomUser.objects.get(id=request.POST['supplier'])
                )
                messages.success(request, 'Request Sent to your agro dealer')
        return redirect(request.path_info)

    context = {
        'requests': requests,
        'forwardtosupplierform': forwardtosupplierform,
        'requestform': requestform,
        'activities': activities
    }
    return render(request, 'dealer/requests.html', context)
@dealer_redirect
@login_required
def report(request):
    total_orders = FertilizerRequest.objects.filter(user__district=request.user.district, user__sector=request.user.sector)
    total_amount = sum(item.category.price * item.quantity for item in total_orders)

    # Stats
    fertilizer_requests_by_category = FertilizerRequest.objects.filter(user__sector=request.user.sector).order_by('category')
    fertilizer_requests = FertilizerRequest.objects.filter(user__sector=request.user.sector).order_by('-created')
    grouped_data = {}
    for key, group in groupby(fertilizer_requests_by_category, key=lambda x: x.category):
        grouped_data[key] = list(group)
    total_by_categories = {}
    for category, items in grouped_data.items():
        total_by_categories[category] = sum(item.category.price * item.quantity for item in items)
    # End Stats

    context = {
        'total_orders': total_orders,
        'total_amount': total_amount,
        'total_by_categories': total_by_categories
    }
    return render(request, 'dealer/report.html', context)
@login_required
def profile(request):
    userform = UserForm(instance=request.user)
    if request.method == 'POST':
        if 'profile-picture-btn' in request.POST:
            request.user.profile_picture = request.FILES['profile_picture']
            request.user.save()
            messages.success(request, 'Picture updated successfully')
        if 'profile-update-btn' in request.POST:
            request.user.first_name = request.POST['first_name']
            request.user.last_name = request.POST['last_name']
            request.user.email = request.POST['email']
            request.user.province = request.POST['province']
            request.user.district = request.POST['district']
            request.user.sector = request.POST['sector']
            request.user.village = request.POST['village']
            request.user.national_id = request.POST['national_id']
            request.user.phone = request.POST['phone']
            request.user.save()
            messages.success(request, 'Profile Updated Successfully')
        return redirect(request.path_info)
    context = {
        'userform': userform
    }
    return render(request, 'core/profile.html', context)



def report_filter(request):
    if request.method == 'POST':
        status = request.POST['category']
        return redirect('dealer-report', status)
    return render(request, 'core/report_filter.html')

@dealer_redirect
@login_required
def report(request, status):
    dealer = request.user
    if status == 'None':
        total_orders = FertilizerRequest.objects.filter(user__sector = dealer.sector, status=None)
    else:
        total_orders = FertilizerRequest.objects.filter(user__sector = dealer.sector, status=status)
    total_amount = sum(item.category.price * item.quantity for item in total_orders)

    # Stats
    # fertilizer_requests_by_category = FertilizerRequest.objects.filter(user__sector=request.user.sector).order_by('category')
    fertilizer_requests = FertilizerRequest.objects.filter(user__sector=request.user.sector).order_by('-created')
    grouped_data = {}
    for key, group in groupby(total_orders, key=lambda x: x.category):
        grouped_data[key] = list(group)
    total_by_categories = {}
    for category, items in grouped_data.items():
        total_by_categories[category] = sum(item.category.price * item.quantity for item in items)
    # End Stats

    context = {
        'total_orders': total_orders,
        'total_amount': total_amount,
        'total_by_categories': total_by_categories,
        'status': status
    }
    return render(request, 'dealer/report.html', context)

