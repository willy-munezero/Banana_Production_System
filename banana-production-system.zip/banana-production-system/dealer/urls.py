from django.urls import path
from . import views

urlpatterns = [
    path('index', views.dealer_dashboard, name='dealer'),
    path('farmers', views.farmers, name='farmers'),
    path('supplierslist', views.suppliers, name='suppliers'),
    path('requests', views.requests, name='requests'),
    path('report', views.report, name='report'),
    path('profile', views.profile, name='dealer-profile'),
    path('reportfilter', views.report_filter, name='dealer-report-filter'),
    path('report/<str:status>/', views.report, name='dealer-report'),

]