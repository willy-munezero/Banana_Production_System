from django.contrib import admin
from .models import CustomUser, UserActivity
from django.contrib.auth.admin import UserAdmin

from import_export.admin import ExportActionMixin
from import_export import resources
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from django.http import HttpResponse
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Image
from reportlab.lib.styles import getSampleStyleSheet
from datetime import datetime
import os
from django.contrib import admin
from import_export.fields import Field
from import_export.formats import base_formats
from django.db.models.fields import BLANK_CHOICE_DASH



admin.site.register(UserActivity)
class MyAdminUser(UserAdmin):
    list_display = ["username","email", "first_name", "last_name","birth_date","is_active"]
    list_filter = ["user_type"]
    fieldsets = [
        (None, {"fields": ["password","username","email"]}),
        ("Personal info", {"fields": ["first_name","last_name","profile_picture","birth_date", "phone", "tin"]}),
        ("Location info", {"fields": ["province","district","sector","village"]}),
        ("Permissions", {"fields": ["is_active","is_superuser","user_type"]}),
    ]
    # add_fieldsets is not a standard ModelAdmin attribute. UserAdmin
    # overrides get_fieldsets to use this attribute when creating a user.
    add_fieldsets = [
        (
            None,
            {
                "classes": ["wide"],
                "fields": ["username", "password1", "password2"],
            },
        ),
    ]
    search_fields = ["email"]
    ordering = ["email"]
    filter_horizontal = []


    def Print_Report(self, request, queryset):
        user_type = request.GET.get('user_type__exact') if request.GET.get('user_type__exact') is not None else "All User"
        pdf_export_title = "List of "+user_type+"s in BPMS"
        queryset_for_export = queryset
        return export_statistics(self, request, queryset_for_export, pdf_export_title)
    
    actions = ['Print_Report']
# Now register the new UserAdmin...
    

def export_statistics(self, request, queryset=None, title=None):
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="ReportExport.pdf"'
    doc = SimpleDocTemplate(response, pagesize=letter)
    p = canvas.Canvas(response, pagesize=letter)
    elements = []

    logo_path = os.getcwd() + '\static\images\\reportlogo.PNG'
    image = Image(logo_path, width=450, height=50) # You can add hAlign='LEFT' attribute to position image
    elements.append(image)
    header = 'RWANDA AGRICULTURAL AND ANIMAL RESOURCES'
    location = 'Rubona, Huye District'
    email = 'info@rab.gov.rw'
    pobox = 'P.O Box 5016'
    elements.append(Paragraph(header))
    elements.append(Paragraph(location))
    elements.append(Paragraph(email))
    elements.append(Paragraph(pobox))
    title_margin_top = 10
    
    # Add title to the PDF (use the provided title or a default title)
    title = title if title is not None else "My Report"
    title_style = getSampleStyleSheet()['Title']
    title_style.spaceAfter = title_margin_top  # Add custom margin-top to the title
    elements.append(Paragraph(title, title_style))



    data = [['No','First Name', 'Last Name',]]  # Table header
    counter = 1
    total = 0
    for obj in queryset:
        data.append([counter, obj.first_name, obj.last_name])
        counter+=1
    
    num_columns = len(data[0])
    page_width, page_height = letter
    # Calculate the total padding for left and right (you can adjust the padding value)
    padding = 50
    total_padding = padding * 2

    # Calculate the width of each column based on the page width, number of columns, and padding
    column_width = (page_width - total_padding) / num_columns

    # Set the width of each column in the table with padding
    col_widths = [column_width] * num_columns

    table = Table(data, colWidths=col_widths)

    style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), 'lightgrey'),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        # ('GRID', (0, 0), (-1, -1), 1, 'black'),
    ])
    table.setStyle(style)
    elements.append(table)

    # Get the user data (first name, last name, username) to be printed in the footer
    user_data = (request.user.first_name.strip(), request.user.last_name.strip(), request.user.username)

    # Build the document and add the footer with the user data
    doc.build(elements, onFirstPage=lambda canvas, doc: add_footer(canvas, doc, user_data),
              onLaterPages=lambda canvas, doc: add_footer(canvas, doc, user_data))

    return response

def add_footer(canvas, doc, user_data):
    first_name, last_name, username = user_data

    if not first_name.strip() and not last_name.strip():
        footer_text = f"Printed by {username} on "+str(datetime.now())
    else:
        footer_text = f"Printed by {first_name} {last_name} on "+str(datetime.now())

    # Reduce font size
    canvas.saveState()
    canvas.setFont("Helvetica", 8)

    # Get the width and height of the footer text
    footer_paragraph = Paragraph(footer_text, getSampleStyleSheet()['Normal'])
    # footer_width, footer_height = footer_paragraph.wrap(doc.width, doc.bottomMargin)

    # Calculate the X coordinate to align the footer at the left margin
    footer_x = doc.leftMargin + 380

    # Calculate the Y coordinate to align the footer at the bottom of the page
    footer_y = doc.bottomMargin + 170

    # Draw the footer at the left margin and bottom of the page
    canvas.drawString(footer_x, footer_y, footer_text)
    canvas.restoreState()

admin.site.register(CustomUser, MyAdminUser)



# Register your models here.
