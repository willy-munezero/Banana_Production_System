# authentication/views.py
from django.shortcuts import render, redirect
from .forms import RegistrationForm, LoginForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from authentication.models import CustomUser
from django.contrib import messages



# register User

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            # Extract user data from the form
            user_obj = form.save(commit=False)
            user_obj.user_type='farmer'
            user_obj.save()
            messages.success(request, 'Account Created, Now Login!')
            return redirect('/login/?next=/dashboard')
    else:
        form = RegistrationForm()

    return render(request, 'authentication/registration.html', {'form': form})


# login User

def login_view(request):
    form = LoginForm()
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                next_url = request.POST.get('next')
                if next_url and next_url.startswith('/'):
                    return redirect(next_url)
                else:
                    return redirect('home')
            else:
                messages.error(request, 'The user does not exist or account disabled. Contact your agro-dealer or Change Password.')
    return render(request, 'authentication/login.html', {'form': form})
