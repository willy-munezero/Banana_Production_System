from django.db import models
from django.contrib.auth.models import AbstractUser

class CustomUser(AbstractUser):
    USER_TYPE_CHOICES = (
        ('farmer', 'farmer'),
        ('cooperative', 'cooperative'),
        ('supplier', 'supplier'),
        ('dealer', 'dealer'),
    )
    birth_date = models.DateField(null=True, blank=True)
    profile_picture = models.ImageField(upload_to='profile_pics/', default='/static/images/default.png', null=True, blank=True)
    province=models.CharField(max_length=50, null=True)
    district=models.CharField(max_length=50, null=True)
    sector=models.CharField(max_length=50, null=True)
    village=models.CharField(max_length=50, null=True)
    tin= models.PositiveIntegerField(null=True, blank=True)
    phone = models.PositiveBigIntegerField(null=True, blank=True)
    national_id = models.PositiveBigIntegerField(null=True, blank=True)
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES, null=True, blank=True)

    def __str__(self) -> str:
        return super().first_name+" "+super().last_name


class UserActivity(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    activity_type = models.CharField(max_length=255)
    timestamp = models.DateTimeField(auto_now_add=True)
    data = models.TextField(blank=True, null=True)  # Optional: store additional data

    class Meta:
        ordering = ['-timestamp']